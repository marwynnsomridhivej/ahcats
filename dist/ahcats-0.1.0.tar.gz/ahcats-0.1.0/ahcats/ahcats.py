import functools
import sys

import aiohttp

from .http import HTTPClient
from .image import HCImage
from .utils import VALID_FORMATS


class Client():
    __slots__ = ['default_format', '_http_client', 'other_kwargs']

    def __init__(self, *, default_format: str = None,
                 session: aiohttp.ClientSession = None, **kwargs):
        self.default_format = default_format.lower() or "jpeg"
        if not self.default_format in VALID_FORMATS:
            self.default_format = "jpeg"
        self._http_client = session or HTTPClient(format=self.default_format)
        self.other_kwargs = kwargs

    @functools.lru_cache(maxsize=None)
    async def get_image(self, error_code: int, **options) -> HCImage:
        """Access the HTTP Cat API to retrieve an image based on the
        HTTP error code

        :param error_code: the HTTP error code
        :type error_code: int
        :param format: "jpeg" or "jpg", "png", or "webp" , 
            defaults to "jpg"
        :type format: str, optional
        :return: instance of HCImage
        :rtype: HCImage
        """
        image_format = options.get("format", self.default_format)
        if not image_format or image_format.lower() not in VALID_FORMATS:
            image_format = self.default_format
        response, url = await self._http_client.get(error_code, format=image_format)
        return HCImage(url, error_code, response)


if int(sys.version_info[0]) < 3:
    raise ImportError(
        "Your version of Python is not supported. Please upgrade to Python 3"
    )

if __name__ == "__main__":
    raise ImportError(
        "This module must be imported instead of directly run"
    )
