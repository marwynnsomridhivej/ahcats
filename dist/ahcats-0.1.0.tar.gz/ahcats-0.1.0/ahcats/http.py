import functools
from typing import Tuple

import aiohttp
import yarl

from ahcats.utils import VALID_FORMATS

from .errors import HTTPError

BASE_URL = "https://http.cat/"


class HTTPClient():
    __slots__ = ["session", "format"]

    def __init__(self, **options) -> None:
        self.session = None
        self.format = options.get("format", "jpeg")
        if not self.format in VALID_FORMATS:
            self.format = "jpeg"

    async def _init_session(self) -> None:
        """Internal function used to initiate an aiohttp ClientSession
        """
        self.session = aiohttp.ClientSession(headers={
            'content-type': f'image/jpeg'
        })

    def _get_url(self, error_code: int, image_format: str) -> str:
        """Internal function to get the URL to be used in the 
        HTTP GET request to the HTTP Cat API

        :param error_code: the HTTP error code
        :type error_code: int
        :param image_format: the image format appended to the URL
        :type image_format: str
        :return: the url to send the HTTP GET request to
        :rtype: str
        """
        url = yarl.URL.build(
            scheme="https",
            host="http.cat/",
            path=f"/{str(error_code)}.{image_format}"
        )
        return str(url)

    @functools.lru_cache(maxsize=None)
    async def get(self, error_code: int, **options) -> Tuple[bytes, str]:
        """Dispatch an HTTP GET request to HTTP Cat API

        :param error_code: the HTTP error code
        :type error_code: int
        :param format: the image format to append to the URL
        :type format: str, optional
        :raises HTTPError: error raised if an error with the HTTP GET 
            request occurred
        :return: tuple containing the image bytes and its URL
        :rtype: Tuple[bytes, str]
        """
        image_format = options.get("format",
                                   self.format if self.format != 'jpeg' else 'jpg')
        url = BASE_URL + str(error_code) + f".{image_format}"
        if not self.session:
            await self._init_session()

        async with self.session.get(url) as response:
            if not 200 <= response.status < 300:
                raise HTTPError(response.status)
            data = await response.read()
        await self.close()
        return data, url

    async def close(self):
        """Internal function to close the active ClientSession, if not 
        already closed
        """
        if self.session:
            await self.session.close()
            self.session = None
