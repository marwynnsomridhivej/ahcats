from io import BytesIO
from pathlib import Path
from typing import Any


VALID_FORMATS = ['jpeg', 'jpg', 'png', 'webp']


def is_path(path: Any) -> bool:
    return isinstance(path, (str, Path, BytesIO))
